import SwiftUI

var greeting = "Hello!"
print(greeting)
